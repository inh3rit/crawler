#!/bin/bash

for ((i=1; i<17; i++)); do
#ssh 'root@spider'${i} <<remotessh
echo "Deploy Server : ${i}";
ssh 'root@spd'${i} <<remotessh
crawler_slave='./crawler-slave';
if [ -d \${crawler_slave} ]; then
    \${crawler_slave}/bin/crawler.sh stop
fi
exit
remotessh
done;
echo 'Stop Success'