#!/bin/bash

for ((i=1; i<17; i++)); do
echo "Deploy Server : ${i}";
ssh 'root@spd'${i} <<remotessh
rm -rf ./logs/crawler-s/*
exit
remotessh
done;
echo 'Clear Success'