#!/bin/bash

for ((i=2; i<3; i++)); do
echo "Deploy Server : ${i}";
ssh 'root@spider'${i} <<remotessh
rm -rf ./logs/crawler-s/*
exit
remotessh
done;
echo 'Clear Success'