#!/bin/bash

if [ ! -n "$1" ]; then
    echo 'must put param f'
    exit 0
fi
while getopts "f:" arg
do
        case $arg in
             f)
                if [ ! -n "$OPTARG" ]; then
                    exit 0;
                fi
                file=$OPTARG
                ;;
             ?) 
                echo "unkonw argument"
                exit 1
                ;;
        esac
done

for ((i=2; i<16; i++)); do
echo "Deploy Server : ${i}";
ssh 'spider@st'${i} <<remotessh
rm -rf crawler-s-bulid.sh
echo '#!/bin/bash
today=`date +%Y%m%d`;
crawler_version='2.1.0';
crawler_slave='./crawler-slave';
crawler_slave_tgz="./crawler-s*.tar.gz";
crawler_back_root='./back';
crawler_back_path=\${crawler_back_root}/\${today};

if [ ! -d \${crawler_back_root} ] ; then
    mkdir \${crawler_back_root};
fi
if [ ! -d \${crawler_back_path} ]; then
    mkdir \${crawler_back_path};
fi
if [ -f \${crawler_slave_tgz} ]; then
    mv \${crawler_slave_tgz} \${crawler_back_path}
fi
if [ -d \${crawler_slave} ]; then
    "\${crawler_slave}/bin/crawler.sh" stop
    rm -rf \${crawler_slave}
fi'>>crawler-s-bulid.sh
sh crawler-s-bulid.sh
rm -rf crawler-s-bulid.sh
exit
remotessh
scp ${file} "spider@st${i}:./"
ssh 'spider@st'${i} <<remotessh
rm -rf crawler-s-bulid.sh
echo 'crawler_version='2.1.0';
crawler_slave='./crawler-slave';
crawler_slave_tgz="./crawler-s*.tar.gz";
tar -zxvf \${crawler_slave_tgz} -C ./
\${crawler_slave}/bin/crawler.sh start'>>crawler-s-bulid.sh
sh crawler-s-bulid.sh
rm -rf crawler-s-bulid.sh
exit
remotessh
done;
echo 'Deploy Success'