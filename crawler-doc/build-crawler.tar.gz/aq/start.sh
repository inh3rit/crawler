#!/bin/bash

for ((i=2; i<7; i++)); do
#ssh 'root@spider'${i} <<remotessh
echo "Deploy Server : ${i}";
ssh 'spider@aq'${i} <<remotessh
crawler_slave='./crawler-slave';
if [ -d \${crawler_slave} ]; then
    "\${crawler_slave}/bin/crawler.sh" start
fi
exit
remotessh
done;
echo 'Start Success'