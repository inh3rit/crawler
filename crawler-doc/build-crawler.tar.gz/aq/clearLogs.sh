#!/bin/bash

for ((i=2; i<7; i++)); do
echo "Deploy Server : ${i}";
ssh 'spider@aq'${i} <<remotessh
rm -rf ./logs/crawler-s/*
exit
remotessh
done;
echo 'Clear Success'