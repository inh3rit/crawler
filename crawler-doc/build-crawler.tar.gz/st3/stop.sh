#!/bin/bash

for ((i=16; i<27; i++)); do
#ssh 'root@spider'${i} <<remotessh
echo "Deploy Server : ${i}";
ssh 'spider@st'${i} <<remotessh
crawler_slave='./crawler-slave';
if [ -d \${crawler_slave} ]; then
    \${crawler_slave}/bin/crawler.sh stop
fi
exit
remotessh
done;
echo 'Stop Success'