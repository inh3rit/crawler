#!/bin/bash

for ((i=16; i<27; i++)); do
echo "Deploy Server : ${i}";
ssh 'spider@st'${i} <<remotessh
rm -rf ./logs/crawler-s/*
exit
remotessh
done;
echo 'Clear Success'